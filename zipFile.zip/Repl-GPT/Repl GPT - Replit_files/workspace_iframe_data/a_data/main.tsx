import __vite__cjsImport0_react_jsxDevRuntime from "/@fs/home/runner/workspace/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6780d8c2"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/@fs/home/runner/workspace/node_modules/.vite/deps/react-dom_client.js?v=6780d8c2"; const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];
import App from "/src/App.tsx";
import "/src/index.css";
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "/home/runner/workspace/client/src/main.tsx?v=HbF9PLvM1N2V6ODh4gDx4",
  lineNumber: 5,
  columnNumber: 53
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSW9EO0FBSnBELFNBQVNBLGtCQUFrQjtBQUMzQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU87QUFFUEQsV0FBV0UsU0FBU0MsZUFBZSxNQUFNLENBQUUsRUFBRUMsT0FBTyx1QkFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBSSxDQUFHIiwibmFtZXMiOlsiY3JlYXRlUm9vdCIsIkFwcCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XG5pbXBvcnQgQXBwIGZyb20gXCIuL0FwcFwiO1xuaW1wb3J0IFwiLi9pbmRleC5jc3NcIjtcblxuY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikhKS5yZW5kZXIoPEFwcCAvPik7XG4iXSwiZmlsZSI6Ii9ob21lL3J1bm5lci93b3Jrc3BhY2UvY2xpZW50L3NyYy9tYWluLnRzeCJ9